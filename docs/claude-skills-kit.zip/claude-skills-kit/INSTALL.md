# Claude Skills Kit — install / update guide

A portable bundle of Claude Code **skills** (playbooks) plus the **runtime kits** (actual
client/server code) behind the code-bearing ones. Use it to install or update these into any app.
The kits target a **Node.js + Express + GCS + React** stack.

## Contents

```
install.mjs                  ← one-command installer (run this)
INSTALL.md                   ← this file
commands/                    ← the payload
├── *.md                     ← all skills (team-*, showcase, …)
└── _shared/
    ├── kits/                ← generic kit installer (lib.mjs, install.mjs, manifest.json)
    ├── i18n-kit/            ← hash i18n runtime + Suggestion Mode (+ AI alternatives)
    ├── help-kit/            ← contextual "?" help assistant
    ├── bugfix-kit/          ← client+server error capture + CLI triage
    ├── showcase-kit/        ← 120s teaser engine + factsheet scaffold
    └── *.md                 ← shared reference specs (CONTEXT_HELP, BUG_TRACKING, invariants, …)
```

> App-specific kits (`lecture-sync`, `class-report`) are **omitted by default** and only present in
> a bundle built with `pack-skills-kit.sh --full`. They assume a particular MyLecture/GCS schema.

## Quick start

```bash
unzip claude-skills-kit.zip -d claude-skills-kit
cd claude-skills-kit

# Preview first (writes nothing)
node install.mjs --app /path/to/your-other-app --kits all --dry-run

# Skills only — always safe (just copies playbooks into .claude/commands/)
node install.mjs --app /path/to/your-other-app

# Skills + all runtime kits
node install.mjs --app /path/to/your-other-app --kits all --admin-tab
```

### Options
| Flag | Meaning |
|------|---------|
| `--app <dir>` | Target app root (default: current dir) |
| `--skills` / `--no-skills` | Copy skills into `<app>/.claude/commands/` (default: on) |
| `--kits all` \| `--kits i18n,help,…` | Also install those runtime kits into the app source |
| `--admin-tab` | (i18n) also install the admin Translations tab component |
| `--dry-run` | Show planned writes, change nothing |
| `--force` | Overwrite existing runtime files (skills/_shared always update) |
| `--list` | List the kits in this bundle |

## What each part installs

- **Skills** (`--skills`, default): copies the `.md` playbooks + `_shared/` into
  `<app>/.claude/commands/`. Pure docs — safe to run anytime; this is how you *update* skills.
- **Runtime kits** (`--kits`): copies real client/server code into the app (e.g. i18n runtime →
  `client/src/i18n/` + `server/i18n/`). Each kit then needs a few **manual wiring steps** —
  the installer prints them, and full detail lives in `commands/_shared/<kit>-kit/README.md`.

## After installing runtime kits — wiring (summary)

- **i18n**: wrap app in `<I18nProvider>`; render text via `<I18nText>`; mount `<SuggestionMode
  canUse={…} getAuthHeaders={…}/>`; mount `createI18nRouter({ storage, requireTeacher, requireAdmin,
  llmTranslate, llmSuggestAlternatives })` at `/server/i18n`; add the 5 `api.js` wrappers. Needs GCS.
  Serve locale files with `Cache-Control: no-cache` for real-time approval updates.
- **help / bugfix / showcase** (and, in `--full` builds, lecture-sync / class-report): see each
  kit's README for its wiring and injected dependencies (storage, auth, LLM, env vars).

## Updating later

Re-run `install.mjs` against the same app. Skills/_shared overwrite in place (that's the update).
Runtime files are skipped unless `--force` (so your local edits aren't clobbered) — review a
`--dry-run --force` first if you want to see what would change.

## Requirements
Node 18+. Kits that persist data need `GCS_BUCKET_NAME`; AI features need an LLM provider key.
This bundle targets a **Node.js + Express + GCS + React** stack. Optional app-specific kits
(lecture-sync, class-report; `--full` builds only) assume a particular MyLecture/GCS schema.
