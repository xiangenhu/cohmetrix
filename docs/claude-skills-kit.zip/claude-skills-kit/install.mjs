#!/usr/bin/env node
/**
 * Claude Skills Kit — bundle installer
 * ===========================================================================
 * Ships as `install.mjs` at the root of the distributable zip. Installs (or
 * UPDATES) the skills and, optionally, their runtime kits into a target app.
 *
 *   node install.mjs --app <target-app-dir> [options]
 *
 * Options:
 *   --app <dir>       Target app root (default: current dir)
 *   --skills          Copy the skills/playbooks into <app>/.claude/commands/ (default: ON)
 *   --no-skills       Skip the skills copy
 *   --kits <list>     Also install runtime kits into the app source. `all` or a
 *                     comma list: i18n,help,bugfix,showcase,lecture-sync,class-report
 *   --admin-tab       (i18n) also install the admin Translations tab component
 *   --dry-run         Show what would happen, write nothing
 *   --force           Overwrite existing runtime files (skills/_shared always update)
 *   --list            List available kits and exit
 *
 * Examples:
 *   node install.mjs --app ../my-other-app                 # skills only (safe)
 *   node install.mjs --app ../my-other-app --kits all      # skills + every runtime
 *   node install.mjs --app ../my-other-app --kits i18n --admin-tab
 */

import { promises as fs } from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const BUNDLE = path.dirname(fileURLToPath(import.meta.url));
const COMMANDS = path.join(BUNDLE, 'commands');           // skills + _shared payload
const SHARED = path.join(COMMANDS, '_shared');
const C = { g:'\x1b[32m', y:'\x1b[33m', c:'\x1b[36m', d:'\x1b[2m', r:'\x1b[31m', x:'\x1b[0m', b:'\x1b[1m' };

function parseArgs(argv) {
  const f = {};
  for (let i = 0; i < argv.length; i++) {
    if (!argv[i].startsWith('--')) continue;
    const k = argv[i].slice(2); const n = argv[i + 1];
    if (!n || n.startsWith('--')) f[k] = true; else { f[k] = n; i++; }
  }
  return f;
}
const flags = parseArgs(process.argv.slice(2));
const app = path.resolve(flags.app || '.');
const dryRun = !!flags['dry-run'];
const doSkills = flags.skills !== undefined ? !!flags.skills : !flags['no-skills'];

const manifest = JSON.parse(await fs.readFile(path.join(SHARED, 'kits', 'manifest.json'), 'utf-8'));

if (flags.list) {
  console.log('\nKits in this bundle:\n');
  for (const k of manifest.kits) console.log(`  ${k.name.padEnd(14)} ${k.description}  ${C.d}(/${k.skill})${C.x}`);
  console.log('');
  process.exit(0);
}

async function exists(p) { try { await fs.access(p); return true; } catch { return false; } }

// Recursively copy a directory (used for the skills/_shared payload).
async function copyTree(src, dst, stats) {
  const entries = await fs.readdir(src, { withFileTypes: true });
  for (const e of entries) {
    const s = path.join(src, e.name), d = path.join(dst, e.name);
    if (e.isDirectory()) { if (!dryRun) await fs.mkdir(d, { recursive: true }); await copyTree(s, d, stats); }
    else {
      const rel = path.relative(app, d);
      if (dryRun) { console.log(`  ${C.c}would write${C.x} ${rel}`); stats.n++; continue; }
      await fs.mkdir(path.dirname(d), { recursive: true });
      await fs.copyFile(s, d);
      stats.n++;
    }
  }
}

console.log(`\n${C.b}Claude Skills Kit — installer${C.x}`);
console.log(`${C.d}target: ${app}${dryRun ? '   (DRY RUN)' : ''}${C.x}`);
if (!(await exists(app))) { console.log(`${C.r}Target app path does not exist: ${app}${C.x}`); process.exit(1); }

// 1) Skills + _shared (the update payload) → <app>/.claude/commands/
if (doSkills) {
  const dst = path.join(app, '.claude', 'commands');
  console.log(`\n${C.b}Skills + shared refs →${C.x} .claude/commands/`);
  const stats = { n: 0 };
  if (!dryRun) await fs.mkdir(dst, { recursive: true });
  await copyTree(COMMANDS, dst, stats);
  console.log(`  ${C.g}${dryRun ? 'would update' : 'updated'} ${stats.n} file(s)${C.x} ${C.d}(skills, _shared kits + refs)${C.x}`);
}

// 2) Optional runtime kits → app source
if (flags.kits) {
  const wanted = flags.kits === true || flags.kits === 'all'
    ? manifest.kits.map(k => k.name)
    : String(flags.kits).split(',').map(s => s.trim()).filter(Boolean);
  const { installKit } = await import(path.join(SHARED, 'kits', 'lib.mjs'));
  for (const name of wanted) {
    const entry = manifest.kits.find(k => k.name === name);
    if (!entry) { console.log(`\n${C.y}skip unknown kit "${name}"${C.x}`); continue; }
    console.log(`\n${C.b}Runtime kit: ${name}${C.x}`);
    const kitArgs = ['--app', app];
    if (dryRun) kitArgs.push('--dry-run');
    if (flags.force) kitArgs.push('--force');
    if (flags['admin-tab']) kitArgs.push('--admin-tab');
    await installKit(path.join(SHARED, entry.dir), kitArgs);
  }
} else {
  console.log(`\n${C.d}No runtime kits installed (skills only). Add --kits all (or a comma list) to install runtime.${C.x}`);
}

console.log(`\n${C.b}Done.${C.x} See ${C.d}INSTALL.md${C.x} in this bundle for wiring + per-kit READMEs under commands/_shared/*-kit/.\n`);
